<?php

namespace Tigren\Dailydeal\Plugin;

use Magento\Checkout\Model\Sidebar;
use Magento\Framework\App\Action\Context;
use Magento\Framework\Json\Helper\Data;
use Psr\Log\LoggerInterface;

/**
 * Class UpdateMinicartQty
 * @package Tigren\Dailydeal\Plugin
 */
class UpdateMinicartQty extends \Magento\Checkout\Controller\Sidebar\UpdateItemQty
{
    protected $_dealFactory;
    protected $_scopeConfig;
    protected $cart;
    protected $_messageManager;
    protected $_urlInterface;

    /**
     * UpdateMinicartQty constructor.
     * @param Context $context
     * @param Sidebar $sidebar
     * @param LoggerInterface $logger
     * @param \Tigren\Dailydeal\Model\DealFactory $dealFactory
     * @param \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig
     * @param \Magento\Checkout\Model\Cart $cart
     * @param \Magento\Framework\Message\Manager $messageManager
     * @param \Magento\Framework\UrlInterface $urlInterface
     * @param Data $jsonHelper
     */
    public function __construct(Context $context,
                                Sidebar $sidebar,
                                LoggerInterface $logger,
                                \Tigren\Dailydeal\Model\DealFactory $dealFactory,
                                \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
                                \Magento\Checkout\Model\Cart $cart,
                                \Magento\Framework\Message\Manager $messageManager,
                                \Magento\Framework\UrlInterface $urlInterface,
                                Data $jsonHelper)
    {
        parent::__construct($context, $sidebar, $logger, $jsonHelper);
        $this->_dealFactory = $dealFactory;
        $this->_scopeConfig = $scopeConfig;
        $this->cart = $cart;
        $this->_messageManager = $messageManager;
        $this->_urlInterface = $urlInterface;
    }

    /**
     * @param \Magento\Checkout\Controller\Sidebar\UpdateItemQty $subject
     * @param \Closure $proceed
     */
    public function aroundExecute(
        \Magento\Checkout\Controller\Sidebar\UpdateItemQty $subject,
        \Closure $proceed
    )
    {
        $itemId = (int)$subject->getRequest()->getParam('item_id');
        $itemQty = $subject->getRequest()->getParam('item_qty') * 1;

        if ($this->getScopeConfig('dailydeal/general/enable')) {
            if($itemId){
                $quoteItem = $this->cart->getQuote()->getItemById($itemId);
                $deal = $this->_dealFactory->create()->loadByProductId($quoteItem->getProduct()->getId());
                if($deal->getId() && $deal->isAvailable()){
                    $dealRemain = $deal->getQuantity() - $deal->getSold();
                    if(!$itemQty){
                        $itemQty = 1;
                    }

                    $quote = $this->cart->getQuote();
                    if (!empty($quote)) {
                        foreach ($quote->getAllItems() as $item) {
                            $productId = $item->getProductId();
                            if ($productId == $itemId) {
                                $itemQty += $item->getQty();
                            }
                        }
                    }

                    if($itemQty > $dealRemain){
                        $prep = ($dealRemain > 1) ? 'are' : 'is';
                        $dealText = ($dealRemain > 1) ? 'deals' : 'deal';
                        $subject->jsonResponse(__("This product is in deal and there $prep $dealRemain $dealText left."));
                    }else{
                        $proceed();
                    }
                }else{
                    $proceed();
                }
            }
        }else{
            $proceed();
        }

    }

    /**
     * @param $path
     * @return mixed
     */
    /**
     * @param $path
     * @return mixed
     */
    public function getScopeConfig($path)
    {
        return $this->_scopeConfig->getValue($path, \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
    }
}