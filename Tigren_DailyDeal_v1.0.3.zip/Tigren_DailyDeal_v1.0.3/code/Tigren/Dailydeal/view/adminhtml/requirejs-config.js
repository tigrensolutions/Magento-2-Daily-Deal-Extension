/**
 * @copyright Copyright (c) 2016 www.tigren.com
 */

var config = {
    paths: {
        chart: 'Tigren_Dailydeal/js/Chart.min',
    }
};