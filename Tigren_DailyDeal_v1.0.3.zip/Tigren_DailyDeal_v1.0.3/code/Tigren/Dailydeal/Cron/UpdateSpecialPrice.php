<?php

namespace Tigren\Dailydeal\Cron;

/**
 * Class UpdateSpecialPrice
 * @package Tigren\Dailydeal\Cron
 */
class UpdateSpecialPrice
{
    /**
     * @var \Magento\Framework\Stdlib\DateTime\Filter\DateTime
     */
    protected $_dateFilter;
    /**
     * @var \Tigren\Dailydeal\Model\DealFactory
     */
    protected $_dealFactory;
    /**
     * @var \Magento\Framework\Stdlib\DateTime\TimezoneInterface
     */
    protected $timezone;
    /**
     * @var \Tigren\Dailydeal\Helper\Data
     */
    protected $_dealHelper;

    /**
     * UpdateSpecialPrice constructor.
     * @param \Tigren\Dailydeal\Model\DealFactory $dealFactory
     * @param \Magento\Framework\Stdlib\DateTime\TimezoneInterface $timezone
     * @param \Tigren\Dailydeal\Helper\Data $dealHelper
     */
    public function __construct(
        \Tigren\Dailydeal\Model\DealFactory $dealFactory,
        \Magento\Framework\Stdlib\DateTime\TimezoneInterface $timezone,
        \Tigren\Dailydeal\Helper\Data $dealHelper,
        \Magento\Framework\Stdlib\DateTime\Filter\DateTime $dateFilter
    )
    {
        $this->_dealFactory = $dealFactory;
        $this->timezone = $timezone;
        $this->_dealHelper = $dealHelper;
        $this->_dateFilter = $dateFilter;
    }

    /**
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     */
    public function execute()
    {
        $deals = $this->_dealFactory->create();
        $currentTime = $this->timezone->date()->format('Y-m-d H:i:s');
        $dealsCollection = $deals->getCollection();
        $dealsCollection->getSelect()->where(
            'main_table.start_time < ?', $currentTime
        )->where(
            'main_table.end_time > ?', $currentTime
        );

        foreach($dealsCollection as $deal){
            if($deal->getId() && $deal->isAvailable()){
                $productIds = $deal->getProductIds();
                foreach($productIds as $productId){
                    $product = $this->_dealHelper->getProductById($productId);
                    $dealPrice = $deal->getPrice();
                    $storeId = $product->getStoreId();
                    if($product->getId()){
                        if($product->getTypeId() == 'configurable'){
                            $childIds = $product->getTypeInstance()->getChildrenIds($product->getId());
                            if (!empty($childIds)) {
                                foreach ($childIds[0] as $childId) {
                                    $childProduct = $this->_dealHelper->getProductById($childId);
                                    if($childProduct->hasSpecialPrice()) {
                                        $oldSpecialPrice = $childProduct->getData('special_price');
                                        $oldSpecialToDate = $childProduct->getSpecialToDate();
                                        $oldSpecialFromDate = $childProduct->getSpecialFromDate();
                                        $deal->getResource()->saveOldSpecialPrice($deal->getId(), $childId, $oldSpecialToDate, $oldSpecialFromDate, $oldSpecialPrice);
                                        $childProduct->addAttributeUpdate('special_to_date', $deal->getDealEndTime($deal->getId()), $storeId);
                                        $childProduct->addAttributeUpdate('special_from_date', $deal->getDealStartTime($deal->getId()), $storeId);
                                        $childProduct->addAttributeUpdate('special_price', $dealPrice, $storeId);
                                        $childProduct->setFinalPrice($dealPrice);
                                    }else{
                                        $childProduct->addAttributeUpdate('special_to_date', $deal->getDealEndTime($deal->getId()), $storeId);
                                        $childProduct->addAttributeUpdate('special_from_date', $deal->getDealStartTime($deal->getId()), $storeId);
                                        $childProduct->addAttributeUpdate('special_price', $dealPrice, $storeId);
                                        $childProduct->setFinalPrice($dealPrice);
                                    }
                                }
                            }
                        }else{
                            if($product->hasSpecialPrice()){
                                $oldSpecialPrice = $product->getData('special_price');
                                $oldSpecialToDate = $product->getSpecialToDate();
                                $oldSpecialFromDate = $product->getSpecialFromDate();
                                $deal->getResource()->saveOldSpecialPrice($deal->getId(), $productId, $oldSpecialToDate, $oldSpecialFromDate, $oldSpecialPrice);
                                $product->addAttributeUpdate('special_to_date',$deal->getDealEndTime($deal->getId()),$storeId);
                                $product->addAttributeUpdate('special_from_date',$deal->getDealStartTime($deal->getId()),$storeId);
                                $product->addAttributeUpdate('special_price',$dealPrice,$storeId);
                                $product->setFinalPrice($dealPrice);
                            }else{
                                $product->addAttributeUpdate('special_to_date',$deal->getDealEndTime($deal->getId()),$storeId);
                                $product->addAttributeUpdate('special_from_date',$deal->getDealStartTime($deal->getId()),$storeId);
                                $product->addAttributeUpdate('special_price',$dealPrice,$storeId);
                                $product->setFinalPrice($dealPrice);
                            }
                        }
                    }

                }
            }elseif($deal->getId()) {
                $endTime = $deal->getDealEndTime($deal->getId());
                if(strtotime($endTime) < strtotime($currentTime)){
                    $productIds = $deal->getProductIds();
                    foreach($productIds as $productId){
                        $product = $this->_dealHelper->getProductById($productId);
                        $storeId = $product->getStoreId();
                        $oldSpecialFromDate = $deal->getProductOldSpecialFromDate($deal->getId(),$productId);
                        if($product->getTypeId() == 'configurable'){
                            $childIds = $product->getTypeInstance()->getChildrenIds($product->getId());
                            if (!empty($childIds)) {
                                foreach ($childIds[0] as $childId) {
                                    $childProduct = $this->_dealHelper->getProductById($childId);
                                    $oldSpecialFromDate = $deal->getProductOldSpecialFromDate($deal->getId(),$childId);
                                    if($childProduct->hasSpecialPrice()){
                                        if(strtotime($childProduct->getData('special_from_date')) < strtotime($oldSpecialFromDate)){
                                            $childProduct->addAttributeUpdate('special_to_date',$deal->getProductOldSpecialToDate($deal->getId(), $productId),$storeId);
                                            $childProduct->addAttributeUpdate('special_from_date',$oldSpecialFromDate,$storeId);
                                            $childProduct->addAttributeUpdate('special_price',$deal->getProductOldSpecialPrice($deal->getId(), $productId),$storeId);
                                        }
                                    }
                                    if(!$oldSpecialFromDate){
                                        $childProduct->addAttributeUpdate('special_to_date',null,$storeId);
                                        $childProduct->addAttributeUpdate('special_from_date',null,$storeId);
                                        $childProduct->addAttributeUpdate('special_price',null,$storeId);
                                    }
                                }
                            }
                        }else{
                            if($product->hasSpecialPrice()){
                                if(strtotime($product->getData('special_from_date')) < strtotime($oldSpecialFromDate)){
                                    $product->addAttributeUpdate('special_to_date',$deal->getProductOldSpecialToDate($deal->getId(), $productId),$storeId);
                                    $product->addAttributeUpdate('special_from_date',$oldSpecialFromDate,$storeId);
                                    $product->addAttributeUpdate('special_price',$deal->getProductOldSpecialPrice($deal->getId(), $productId),$storeId);
                                }
                            }
                            if(!$oldSpecialFromDate){
                                $product->addAttributeUpdate('special_to_date',null,$storeId);
                                $product->addAttributeUpdate('special_from_date',null,$storeId);
                                $product->addAttributeUpdate('special_price',null,$storeId);
                            }
                        }
                    }
                }
            }
        }
    }

    /**
     * @param string $dateTime
     * @param string $toTz
     * @param string $fromTz
     * @return string
     * @throws \Exception
     */
    protected function converToTz($dateTime = '', $fromTz = '')
    {
        $dateTime = $this->_dateFilter->filter($dateTime);
        // timezone by php friendly values
        $date = new \DateTime($dateTime, new \DateTimeZone($fromTz));

        $dateTime = $date->format('Y-m-d H:i:s');

        return $dateTime;
    }
}