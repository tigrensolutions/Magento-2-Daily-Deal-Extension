<?php
/**
 * @copyright Copyright (c) 2016 www.tigren.com
 */

namespace Tigren\Dailydeal\Block\Deals;

/**
 * Class TodayDeals
 * @package Tigren\Dailydeal\Block\Deals
 */
class TodayDeals extends \Magento\Framework\View\Element\Template
{

    protected $_dealFactory;
    protected $_dailydealHelper;
    protected $_deals;
    protected $_timezone;
    protected $_productFactory;


    /**
     * TodayDeals constructor.
     * @param \Magento\Framework\View\Element\Template\Context $context
     * @param \Tigren\Dailydeal\Model\DealFactory $dealFactory
     * @param \Tigren\Dailydeal\Helper\Data $dailydealHelper
     * @param \Magento\Framework\Stdlib\DateTime\TimezoneInterface $timezone
     * @param \Magento\Catalog\Model\ProductFactory $productFactory
     * @param array $data
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     */
    public function __construct(
        \Magento\Framework\View\Element\Template\Context $context,
        \Tigren\Dailydeal\Model\DealFactory $dealFactory,
        \Tigren\Dailydeal\Helper\Data $dailydealHelper,
        \Magento\Framework\Stdlib\DateTime\TimezoneInterface $timezone,
        \Magento\Catalog\Model\ProductFactory $productFactory,
        array $data = []
    ) {
        parent::__construct($context, $data);
        $this->_dealFactory = $dealFactory;
        $this->_dailydealHelper = $dailydealHelper;
        $this->_timezone = $timezone;
        $this->_productFactory = $productFactory;
        $this->_deals = $this->getTodayDealCollection();
    }

    /**
     * @return $this|\Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     */
    public function getTodayDealCollection()
    {
        //get values of current page
        $page=($this->getRequest()->getParam('p'))? $this->getRequest()->getParam('p') : 1;
        //get values of current limit
        $pageSize=($this->getRequest()->getParam('limit'))? $this->getRequest
        ()->getParam('limit') : 5;
        $storeIds = [0, $this->getCurrentStoreId()];
        $productCollection = $this->_productFactory->create()->getCollection();
        $currentTime = $this->_timezone->date()->format('Y-m-d H:i:s');
        $productCollection->getSelect()->join(
            ['deal_product' => $productCollection->getTable('tigren_dailydeal_deal_product')],
            'e.entity_id = deal_product.product_id',
            []
        )->join(
            ['deal' => $productCollection->getTable('tigren_dailydeal_deal')],
            'deal.deal_id = deal_product.deal_id',
            ['deal_price' => 'price','*']
        )->where(
            'deal.start_time < ?', $currentTime
        )->where(
            'deal.end_time > ?', $currentTime
        )->where(
            'deal.status = ?', 1
        );
        if($storeIds) {
            if ($this->_storeManager->isSingleStoreMode()) {
                return $this;
            }
            $connection = $productCollection->getConnection();
            if (!is_array($storeIds)) {
                $storeIds = [$storeIds === null ? -1 : $storeIds];
            }
            if (empty($storeIds)) {
                return $this;
            }
            $productCollection->getSelect()->distinct(true)->join(
                ['store_table' => $productCollection->getTable('tigren_dailydeal_deal_store')],
                'deal.deal_id = store_table.deal_id',
                []
            );
            $inCondition = $connection->prepareSqlCondition('store_table.store_id', ['in' => $storeIds]);
            $productCollection->getSelect()->where($inCondition);
        }
        $productCollection->addFieldToFilter(
            'visibility',['neq' => 1]
        )->setPageSize(
            $pageSize
        )->setCurPage(
            $page
        );
//        $collection = $this->_dealFactory->create()->getCollection()
//            ->addFieldToFilter('status', \Tigren\Dailydeal\Model\Deal::STATUS_ENABLED)
//            ->setTodayFilter()
//            ->setStoreFilter($storeIds)
//            ->setOrder('deal_id', 'DESC');
        return $productCollection;
    }

    /**
     * @return int
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     */
    /**
     * @return int
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     */
    public function getCurrentStoreId()
    {
        return $this->_storeManager->getStore(true)->getId();
    }

    /**
     * @return array
     */
    /**
     * @return array
     */
    public function getIdentities()
    {
        return [\Tigren\Dailydeal\Model\Deal::CACHE_TAG . '_' . 'today'];
    }

    /**
     * @return int
     */
    /**
     * @return int
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     */
    public function getLimit()
    {
        $limit = (int)$this->getScopeConfig('dailydeal/general/deal_per_page');
        if (empty($limit)) {
            $limit = 9;
        }
        return $limit;
    }

    /**
     * @param $path
     * @return mixed
     */
    /**
     * @param $path
     * @return mixed
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     */
    public function getScopeConfig($path)
    {
        $storeId = $this->getCurrentStoreId();
        return $this->_scopeConfig->getValue($path, \Magento\Store\Model\ScopeInterface::SCOPE_STORE, $storeId);
    }

    /**
     * @return \Tigren\Dailydeal\Helper\Data
     */
    /**
     * @return \Tigren\Dailydeal\Helper\Data
     */
    public function getHelper()
    {
        return $this->_dailydealHelper;
    }

    /**
     * @return \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection|TodayDeals
     */
    /**
     * @return \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection|TodayDeals
     */
    public function getPagedDeals()
    {
        return $this->_deals;
    }

    /**
     * @return string
     */
    /**
     * @return string
     */
    public function getPagerHtml()
    {
        return $this->getChildHtml('pager');
    }

    /**
     * @return $this|\Magento\Framework\View\Element\Template
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    /**
     * @return $this
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    protected function _prepareLayout()
    {
        parent::_prepareLayout();
        $this->pageConfig->getTitle()->set(__('Today Deal'));
        if ($this->_deals) {
            $pager = $this->getLayout()->createBlock('Magento\Theme\Block\Html\Pager', 'dailydeal.deal.today.pager')
                ->setAvailableLimit([5 => 5, 10 => 10, 20 => 20, 30 => 30])
                ->setShowPerPage(true)
                ->setCollection($this->_deals);
            $this->setChild('pager', $pager);
            $this->_deals->load();
        }
        return $this;
    }

}
