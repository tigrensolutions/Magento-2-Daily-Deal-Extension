<?php
/**
 * @copyright Copyright (c) 2016 www.tigren.com
 */

namespace Tigren\Dailydeal\Block;

/**
 * Class Sidebar
 * @package Tigren\Dailydeal\Block
 */
class Sidebar extends \Magento\Catalog\Block\Product\AbstractProduct
{
    protected $_dealFactory;
    protected $_dailydealHelper;
    protected $urlHelper;
    protected $_formKey;
    protected $_timezone;
    protected $_productFactory;

    /**
     * Sidebar constructor.
     * @param \Magento\Catalog\Block\Product\Context $context
     * @param \Tigren\Dailydeal\Model\DealFactory $dealFactory
     * @param \Tigren\Dailydeal\Helper\Data $dailydealHelper
     * @param \Magento\Framework\Url\Helper\Data $urlHelper
     * @param \Magento\Framework\Data\Form\FormKey $formKey
     * @param \Magento\Framework\Stdlib\DateTime\TimezoneInterface $timezone
     * @param \Magento\Catalog\Model\ProductFactory $productFactory
     * @param array $data
     */
    public function __construct(
        \Magento\Catalog\Block\Product\Context $context,
        \Tigren\Dailydeal\Model\DealFactory $dealFactory,
        \Tigren\Dailydeal\Helper\Data $dailydealHelper,
        \Magento\Framework\Url\Helper\Data $urlHelper,
        \Magento\Framework\Data\Form\FormKey $formKey,
        \Magento\Framework\Stdlib\DateTime\TimezoneInterface $timezone,
        \Magento\Catalog\Model\ProductFactory $productFactory,
        array $data = []
    ) {
        parent::__construct($context, $data);
        $this->_dealFactory = $dealFactory;
        $this->_dailydealHelper = $dailydealHelper;
        $this->urlHelper = $urlHelper;
        $this->_formKey = $formKey;
        $this->_timezone = $timezone;
        $this->_productFactory = $productFactory;
    }

    /**
     * @return array
     */
    public function getIdentities()
    {
        return [\Tigren\Dailydeal\Model\Deal::CACHE_TAG . '_' . 'sidebar'];
    }

    /**
     * @return int
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     */
    public function getLimit()
    {
        $limit = (int)$this->getScopeConfig('dailydeal/general/num_of_sidebar_deals');
        if (empty($limit)) {
            $limit = 3;
        }
        return $limit;
    }

    /**
     * @param $path
     * @return mixed
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     */
    public function getScopeConfig($path)
    {
        $storeId = $this->getCurrentStoreId();
        return $this->_scopeConfig->getValue($path, \Magento\Store\Model\ScopeInterface::SCOPE_STORE, $storeId);
    }

    /**
     * @return int
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     */
    public function getCurrentStoreId()
    {
        return $this->_storeManager->getStore(true)->getId();
    }

    /**
     * @return \Tigren\Dailydeal\Helper\Data
     */
    public function getHelper()
    {
        return $this->_dailydealHelper;
    }

    /**
     * @return $this|\Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
     */
    public function getTodayDealCollection()
    {
        $storeIds = [0, $this->getCurrentStoreId()];
        $productCollection = $this->_productFactory->create()->getCollection();
        $currentTime = $this->_timezone->date()->format('Y-m-d H:i:s');
        $productCollection->getSelect()->join(
            ['deal_product' => $productCollection->getTable('tigren_dailydeal_deal_product')],
            'e.entity_id = deal_product.product_id',
            []
        )->join(
            ['deal' => $productCollection->getTable('tigren_dailydeal_deal')],
            'deal.deal_id = deal_product.deal_id',
            ['deal_price' => 'price','*']
        )->where(
            'deal.start_time < ?', $currentTime
        )->where(
            'deal.end_time > ?', $currentTime
        )->where(
            'deal.status = ?', 1
        );
        if($storeIds) {
            if ($this->_storeManager->isSingleStoreMode()) {
                return $this;
            }
            $connection = $productCollection->getConnection();
            if (!is_array($storeIds)) {
                $storeIds = [$storeIds === null ? -1 : $storeIds];
            }
            if (empty($storeIds)) {
                return $this;
            }
            $productCollection->getSelect()->distinct(true)->join(
                ['store_table' => $productCollection->getTable('tigren_dailydeal_deal_store')],
                'deal.deal_id = store_table.deal_id',
                []
            );
            $inCondition = $connection->prepareSqlCondition('store_table.store_id', ['in' => $storeIds]);
            $productCollection->getSelect()->where($inCondition);
        }
        $productCollection->addFieldToFilter(
            'visibility',['neq' => 1]
        );
        return $productCollection;
    }

    /**
     * @param \Magento\Catalog\Model\Product $product
     * @return array
     */
    /**
     * @param \Magento\Catalog\Model\Product $product
     * @return array
     */
    public function getAddToCartPostParams(\Magento\Catalog\Model\Product $product)
    {
        $url = $this->getAddToCartUrl($product);
        return [
            'url' => $url,
            'product' => $product->getEntityId(),
            \Magento\Framework\App\ActionInterface::PARAM_NAME_URL_ENCODED => $this->urlHelper->getEncodedUrl($url),
            'formkey' => $this->_formKey->getFormKey()
        ];
    }

}
