<?php
/**
 * @copyright Copyright (c) 2016 www.tigren.com
 */

namespace Tigren\Dailydeal\Block\Product;

use Magento\Catalog\Api\CategoryRepositoryInterface;
use Magento\Catalog\Block\Product\Context;
use Magento\Catalog\Model\Layer\Resolver;
use Magento\Framework\Data\Helper\PostHelper;
use Magento\Framework\Url\Helper\Data;

/**
 * Class Deal
 * @package Tigren\Dailydeal\Block\Product
 */
class Deal extends \Magento\Catalog\Block\Product\ListProduct
{
    protected $_coreRegistry = null;
    protected $_dealFactory;
    protected $_dailydealHelper;
    protected $_productloader;
    public $options = [];

    /**
     * Deal constructor.
     * @param Context $context
     * @param PostHelper $postDataHelper
     * @param Resolver $layerResolver
     * @param CategoryRepositoryInterface $categoryRepository
     * @param \Magento\Framework\Registry $registry
     * @param \Tigren\Dailydeal\Model\DealFactory $dealFactory
     * @param \Tigren\Dailydeal\Helper\Data $dailydealHelper
     * @param \Magento\Catalog\Model\ProductFactory $_productloader
     * @param Data $urlHelper
     * @param array $data
     */
    public function __construct(
        Context $context,
        PostHelper $postDataHelper,
        Resolver $layerResolver,
        CategoryRepositoryInterface $categoryRepository,
        \Magento\Framework\Registry $registry,
        \Tigren\Dailydeal\Model\DealFactory $dealFactory,
        \Tigren\Dailydeal\Helper\Data $dailydealHelper,
        \Magento\Catalog\Model\ProductFactory $_productloader,
        Data $urlHelper, array $data = [])
    {
        $this->_coreRegistry = $registry;
        $this->_dealFactory = $dealFactory;
        $this->_dailydealHelper = $dailydealHelper;
        $this->_productloader = $_productloader;
        parent::__construct($context, $postDataHelper, $layerResolver, $categoryRepository, $urlHelper, $data);
    }

    /**
     * @return array
     */
    public function getIdentities()
    {
        return [\Tigren\Dailydeal\Model\Deal::CACHE_TAG . '_' . 'product_deal'];
    }

    /**
     * @return \Tigren\Dailydeal\Helper\Data
     */
    public function getHelper()
    {
        return $this->_dailydealHelper;
    }

    /**
     * @param $path
     * @return mixed
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     */
    public function getScopeConfig($path)
    {
        $storeId = $this->getCurrentStoreId();
        return $this->_scopeConfig->getValue($path, \Magento\Store\Model\ScopeInterface::SCOPE_STORE, $storeId);
    }

    /**
     * @return int
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     */
    public function getCurrentStoreId()
    {
        return $this->_storeManager->getStore(true)->getId();
    }

    /**
     * @return \Magento\Catalog\Model\Product|mixed
     */
    public function getProduct()
    {
        return $this->_coreRegistry->registry('current_product');
    }

    /**
     * @param $productId
     * @return \Tigren\Dailydeal\Model\Deal
     */
    public function getDealForProduct($productId)
    {
        return $this->_dealFactory->create()->loadByProductId($productId);
    }

    /**
     * @param $dealId
     * @return array
     */
    public function getProductByDealId($dealId)
    {
        $deals = $this->getHelper()->getCollectionByDealId($dealId);
        foreach ($deals->getProductIds() as $item){
            $product[] =  $this->_productloader->create()->load($item);
        }
        return $product;
    }
}
