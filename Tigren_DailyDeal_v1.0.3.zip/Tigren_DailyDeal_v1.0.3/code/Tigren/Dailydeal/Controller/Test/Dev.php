<?php
/**
 * @copyright Copyright (c) 2016 www.tigren.com
 */

namespace Tigren\Dailydeal\Controller\Test;

use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\Context;

/**
 * Class Dev
 * @package Tigren\Dailydeal\Controller\Test
 */
class Dev extends Action
{
    /**
     * Dev constructor.
     * @param Context $context
     */
    public function __construct(Context $context)
    {
        parent::__construct($context);
    }

    /**
     * @return \Magento\Framework\App\ResponseInterface|\Magento\Framework\Controller\ResultInterface|void
     */
    public function execute()
    {
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $cron = $objectManager->get('Tigren\Dailydeal\Cron\UpdateSpecialPrice');

        echo '<pre>';
        print_r('Start cron');
        $cron->execute();

        echo '<br>';
        print_r('End cron');
    }
}
