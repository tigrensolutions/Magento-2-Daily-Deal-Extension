<?php
/**
 * @copyright Copyright (c) 2016 www.tigren.com
 */

namespace Tigren\Dailydeal\Observer;

use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;

/**
 * Class AfterOrderPlaced
 * @package Tigren\Dailydeal\Observer
 */
class AfterOrderPlaced implements ObserverInterface
{

    protected $_dealFactory;
    protected $_scopeConfig;
    protected $_dailydealHelper;
    protected $logger;

    /**
     * AfterOrderPlaced constructor.
     * @param \Tigren\Dailydeal\Model\DealFactory $dealFactory
     * @param \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig
     * @param \Tigren\Dailydeal\Helper\Data $dailydealHelper
     * @param \Psr\Log\LoggerInterface $logger
     */
    public function __construct(
        \Tigren\Dailydeal\Model\DealFactory $dealFactory,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        \Tigren\Dailydeal\Helper\Data $dailydealHelper,
        \Psr\Log\LoggerInterface $logger
    ) {
        $this->_dealFactory = $dealFactory;
        $this->_scopeConfig = $scopeConfig;
        $this->_dailydealHelper = $dailydealHelper;
        $this->logger = $logger;

    }

    /**
     * @param Observer $observer
     */
    public function execute(Observer $observer)
    {

        $orderModel = $observer->getOrder();
        $items = $orderModel->getItems();
        foreach ($items as $item) {
            if ($this->getScopeConfig('dailydeal/general/enable')) {
                $deal = $this->_dealFactory->create()->loadByProductId($item->getProductId());
                if ($deal->getId()) {
                    if ($deal->isAvailable()) {
                        $productId = $item->getProductId();
                        $currentDealProductQty = $deal->getDealProductQty($productId);
                        $dealProductRemain = $currentDealProductQty - $item->getQtyOrdered();
                        $deal->updateDealProductQty($productId, $dealProductRemain);
                        $deal->setSold((int)$deal->getSold() + $item->getQtyOrdered());
                        try {
                            $deal->save();
                            $this->_dailydealHelper->refreshLocalDeals();
                        } catch (\Exception $e) {
                            $this->logger->critical($e);
                        }
                    }
                }
            }
        }
    }

    /**
     * @param $path
     * @return mixed
     */
    public function getScopeConfig($path)
    {
        return $this->_scopeConfig->getValue($path, \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
    }

}
