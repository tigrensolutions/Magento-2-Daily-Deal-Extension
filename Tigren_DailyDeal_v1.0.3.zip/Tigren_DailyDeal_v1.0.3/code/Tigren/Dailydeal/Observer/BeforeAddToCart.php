<?php
/**
 * @copyright Copyright (c) 2016 www.tigren.com
 */

namespace Tigren\Dailydeal\Observer;

use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;

/**
 * Class BeforeAddToCart
 * @package Tigren\Dailydeal\Observer
 */
class BeforeAddToCart implements ObserverInterface
{

    protected $_dealFactory;
    protected $_scopeConfig;
    protected $cart;
    protected $_messageManager;
    protected $_urlInterface;
    /**
     * @var \Magento\Customer\Model\Session
     */
    protected $_customerSession;

    /**
     * BeforeAddToCart constructor.
     * @param \Tigren\Dailydeal\Model\DealFactory $dealFactory
     * @param \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig
     * @param \Magento\Checkout\Model\Cart $cart
     * @param \Magento\Framework\Message\Manager $messageManager
     * @param \Magento\Framework\UrlInterface $urlInterface
     */
    public function __construct(
        \Tigren\Dailydeal\Model\DealFactory $dealFactory,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        \Magento\Checkout\Model\Cart $cart,
        \Magento\Framework\Message\Manager $messageManager,
        \Magento\Framework\UrlInterface $urlInterface,
        \Magento\Customer\Model\Session $customerSession
    ) {
        $this->_dealFactory = $dealFactory;
        $this->_scopeConfig = $scopeConfig;
        $this->cart = $cart;
        $this->_messageManager = $messageManager;
        $this->_urlInterface = $urlInterface;
        $this->_customerSession = $customerSession;
    }

    /**
     * @param Observer $observer
     */
    public function execute(Observer $observer)
    {
        if ($this->getScopeConfig('dailydeal/general/enable')) {
            $addedItemId = $observer->getRequest()->getParam('product');
            if ($addedItemId) {
                $deal = $this->_dealFactory->create()->loadByProductId($addedItemId);
                if ($deal->getId() && $deal->isAvailable()) {
                    $dealProductRemain = $deal->getDealProductQty($addedItemId);
                    $addedQty = $observer->getRequest()->getParam('qty');
                    if (!$addedQty) {
                        $addedQty = 1;
                    }

                    $quote = $this->cart->getQuote();
                    if (!empty($quote)) {
                        foreach ($quote->getAllItems() as $item) {
                            $productId = $item->getProductId();

                            if ($productId == $addedItemId) {
                                $addedQty += $item->getQty();
                            }
                        }
                    }
                    if ($addedQty > $dealProductRemain) {
                        $observer->getRequest()->setParam('product', false);
                        $prep = ($dealProductRemain > 1) ? 'are' : 'is';
                        $dealText = ($dealProductRemain > 1) ? 'deals' : 'deal';
                        $errorMessage = __("This product is in deal and there $prep $dealProductRemain $dealText left.");
                        $this->_customerSession->setDealQtyOver($errorMessage);
                        $this->_messageManager->addError($errorMessage);
                    }

                }
            }
        }
    }

    /**
     * @param $path
     * @return mixed
     */
    /**
     * @param $path
     * @return mixed
     */
    public function getScopeConfig($path)
    {
        return $this->_scopeConfig->getValue($path, \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
    }

}
