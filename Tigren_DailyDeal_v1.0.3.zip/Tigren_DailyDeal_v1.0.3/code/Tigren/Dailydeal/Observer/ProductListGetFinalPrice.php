<?php
/**
 * @copyright Copyright (c) 2016 www.tigren.com
 */

namespace Tigren\Dailydeal\Observer;

use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;

/**
 * Class ProductListGetFinalPrice
 * @package Tigren\Dailydeal\Observer
 */
class ProductListGetFinalPrice implements ObserverInterface
{

    protected $_dealFactory;
    protected $_scopeConfig;
    protected $_productFactory;

    /**
     * ProductListGetFinalPrice constructor.
     * @param \Tigren\Dailydeal\Model\DealFactory $dealFactory
     * @param \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig
     * @param \Magento\Catalog\Model\ProductFactory $productFactory
     */
    public function __construct(
        \Tigren\Dailydeal\Model\DealFactory $dealFactory,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        \Magento\Catalog\Model\ProductFactory $productFactory
    ) {
        $this->_dealFactory = $dealFactory;
        $this->_scopeConfig = $scopeConfig;
        $this->_productFactory = $productFactory;
    }

    /**
     * @param Observer $observer
     */
    public function execute(Observer $observer)
    {
        $products = $observer->getCollection();
        if ($products->getSize() > 0) {
            foreach ($products->getItems() as $product) {
                if ($this->getScopeConfig('dailydeal/general/enable')) {
                    $deal = $this->_dealFactory->create()->loadByProductId($product->getId());
                    if ($deal->getId() && $deal->isAvailable()) {
                        $startTime = date('Y-m-d H:i:s', strtotime($deal->getDealStartTime($deal->getId())));
                        $endTime = date('Y-m-d H:i:s', strtotime($deal->getDealEndTime($deal->getId())));
                        $product->setSpecialFromDate($startTime);
                        $product->setSpecialToDate($endTime);
                        $product->setSpecialPrice($deal->getPrice());
                        $product->setFinalPrice($deal->getPrice());
                    }
                }
            }
        }
    }

    /**
     * @param $path
     * @return mixed
     */
    public function getScopeConfig($path)
    {
        return $this->_scopeConfig->getValue($path, \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
    }

}
