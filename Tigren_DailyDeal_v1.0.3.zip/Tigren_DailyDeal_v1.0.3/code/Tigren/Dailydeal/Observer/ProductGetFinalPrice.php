<?php
/**
 * @copyright Copyright (c) 2016 www.tigren.com
 */

namespace Tigren\Dailydeal\Observer;

use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;

/**
 * Class ProductGetFinalPrice
 * @package Tigren\Dailydeal\Observer
 */
class ProductGetFinalPrice implements ObserverInterface
{

    protected $_dealFactory;
    protected $_scopeConfig;
    protected $_productFactory;

    /**
     * ProductGetFinalPrice constructor.
     * @param \Tigren\Dailydeal\Model\DealFactory $dealFactory
     * @param \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig
     * @param \Magento\Catalog\Model\ProductFactory $prductFactory
     */
    public function __construct(
        \Tigren\Dailydeal\Model\DealFactory $dealFactory,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        \Magento\Catalog\Model\ProductFactory $prductFactory
    ) {
        $this->_dealFactory = $dealFactory;
        $this->_scopeConfig = $scopeConfig;
        $this->_productFactory = $prductFactory;
    }

    /**
     * @param Observer $observer
     */
    public function execute(Observer $observer)
    {
        if ($this->getScopeConfig('dailydeal/general/enable')) {
            $product = $observer->getEvent()->getProduct();
            $deal = $this->_dealFactory->create()->loadByProductId($product->getId());
            if ($deal->getId() && $deal->isAvailable()) {
                $startTime = date('Y-m-d H:i:s', strtotime($deal->getDealStartTime($deal->getId())) - 86400);
                $endTime = date('Y-m-d H:i:s', strtotime($deal->getDealEndTime($deal->getId())) - 86400);
                $product->setSpecialFromDate($startTime);
                $product->setSpecialToDate($endTime);
                $product->setSpecialPrice($deal->getPrice());
                $product->setFinalPrice($deal->getPrice());
            }
        }
    }

    /**
     * @param $path
     * @return mixed
     */
    public function getScopeConfig($path)
    {
        return $this->_scopeConfig->getValue($path, \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
    }

}
