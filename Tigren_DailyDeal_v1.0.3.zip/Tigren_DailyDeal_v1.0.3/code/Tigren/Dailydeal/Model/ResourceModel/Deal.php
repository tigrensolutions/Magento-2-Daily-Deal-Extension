<?php
/**
 * @copyright Copyright (c) 2016 www.tigren.com
 */

namespace Tigren\Dailydeal\Model\ResourceModel;

use Magento\Framework\Model\AbstractModel;

/**
 * Mysql resource
 */
class Deal extends \Magento\Framework\Model\ResourceModel\Db\AbstractDb
{
    /**
     * @var
     */
    protected $_dealTable;
    /**
     * @var
     */
    protected $_dealStoreTable;
    /**
     * @var
     */
    protected $_dealProductTable;
    /**
     * @var \Magento\Catalog\Model\ProductFactory
     */
    protected $_productFactory;
    /**
     * @var \Tigren\Dailydeal\Model\DealFactory
     */
    protected $_dealFactory;
    /**
     * @var \Magento\Framework\Stdlib\DateTime\DateTime
     */
    protected $_date;
    /**
     * @var \Magento\Store\Model\StoreManagerInterface
     */
    protected $_storeManager;
    /**
     * @var \Tigren\Dailydeal\Helper\Data
     */
    protected $_dailydealHelper;
    /**
     * @var \Magento\Catalog\Api\ProductRepositoryInterface
     */
    protected $_productRepository;
    /**
     * @var \Magento\Framework\Stdlib\DateTime\TimezoneInterface
     */
    protected $_timezone;
    /**
     * @var \Magento\Framework\Stdlib\DateTime\Filter\DateTime
     */
    protected $_dateFilter;

    /**
     * Deal constructor.
     * @param \Magento\Framework\Model\ResourceModel\Db\Context $context
     * @param \Magento\Catalog\Model\ProductFactory $prductFactory
     * @param \Tigren\Dailydeal\Model\DealFactory $dealFactory
     * @param \Magento\Framework\Stdlib\DateTime\DateTime $date
     * @param \Magento\Store\Model\StoreManagerInterface $storeManager
     * @param \Tigren\Dailydeal\Helper\Data $dailydealHelper
     * @param null $resourcePrefix
     */
    public function __construct(
        \Magento\Framework\Model\ResourceModel\Db\Context $context,
        \Magento\Catalog\Model\ProductFactory $prductFactory,
        \Tigren\Dailydeal\Model\DealFactory $dealFactory,
        \Magento\Framework\Stdlib\DateTime\DateTime $date,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Tigren\Dailydeal\Helper\Data $dailydealHelper,
        \Magento\Catalog\Api\ProductRepositoryInterface $productRepository,
        \Magento\Framework\Stdlib\DateTime\TimezoneInterface $timezone,
        \Magento\Framework\Stdlib\DateTime\Filter\DateTime $dateFilter,
        $resourcePrefix = null
    )
    {
        parent::__construct($context, $resourcePrefix);
        $this->_productFactory = $prductFactory;
        $this->_dealFactory = $dealFactory;
        $this->_date = $date;
        $this->_storeManager = $storeManager;
        $this->_dailydealHelper = $dailydealHelper;
        $this->_productRepository = $productRepository;
        $this->_timezone = $timezone;
        $this->_dateFilter = $dateFilter;
    }

    /**
     * @param $productId
     */
    public function deleteAssociations($productId)
    {
        if ($productId) {
            $condition = ['product_id = ?' => $productId];
            $connection = $this->getConnection();
            $connection->delete($this->_dealProductTable, $condition);
        }
    }

    /**
     * @param $productId
     * @return string
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     */
    public function getDealByProductId($productId)
    {
        $storeIds = ['0', $this->getCurrentStoreId()];

        $select = $this->getConnection()->quoteInto("
            SELECT d.`deal_id`
            FROM $this->_dealTable as d
            INNER JOIN $this->_dealStoreTable as s
                ON s.`deal_id` = d.`deal_id`
            INNER JOIN $this->_dealProductTable as dp
                ON d.`deal_id` = dp.`deal_id`
                AND s.`store_id` IN (?)
                AND dp.product_id = $productId
            GROUP BY d.`deal_id`
        ", $storeIds);
        return $this->getConnection()->fetchOne($select);
    }

    /**
     * @return int
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     */
    public function getCurrentStoreId()
    {
        return $this->_storeManager->getStore(true)->getId();
    }

    /**
     * @return array
     */
    public function getTodayDealsEndTime()
    {
        $productTable = $this->getTable('catalog_product_entity');
        $storeIds = [0, $this->getCurrentStoreId()];

        $select = $this->getConnection()->quoteInto("
            SELECT dp.`product_id`, d.`end_time`
            FROM $this->_dealTable as d
            INNER JOIN $this->_dealStoreTable as s
                ON s.`deal_id` = d.`deal_id`
            INNER JOIN $this->_dealProductTable as dp
                ON d.`deal_id` = dp.`deal_id`
            INNER JOIN $productTable as p
                ON dp.`product_id` = p.`entity_id`
            WHERE (d.`start_time` < now() AND d.`end_time` > now())
                AND d.`status` = " . \Tigren\Dailydeal\Model\Deal::STATUS_ENABLED . "
                AND (d.`quantity` - d.`sold`) > 0
                AND s.`store_id` IN (?)
            GROUP BY dp.`product_id`
            ORDER BY d.`price` ASC
        ", $storeIds);

        return $this->getConnection()->fetchAll($select);
    }

    /**
     *
     */
    protected function _construct()
    {
        $this->_init('tigren_dailydeal_deal', 'deal_id');
        $this->_dealTable = $this->getTable('tigren_dailydeal_deal');
        $this->_dealStoreTable = $this->getTable('tigren_dailydeal_deal_store');
        $this->_dealProductTable = $this->getTable('tigren_dailydeal_deal_product');

    }

    /**
     * @param AbstractModel $object
     * @return $this
     */
    protected function _afterLoad(AbstractModel $object)
    {
        parent::_afterLoad($object);
        if (!$object->getId()) {   //if create new
            return $this;
        }

        //Process time
        if ($object->hasStartTime()) {
            $startTime = date('Y-m-d H:i:s',
                $this->_date->timestamp($object->getStartTime()) + $this->_date->getGmtOffset());
            $object->setStartTime($startTime);
        }
        if ($object->hasEndTime()) {
            $endTime = date('Y-m-d H:i:s',
                $this->_date->timestamp($object->getEndTime()) + $this->_date->getGmtOffset());
            $object->setEndTime($endTime);
        }

        if ($object->getId()) {
            $object->setStores($this->getStoreIds((int)$object->getId()));
            $object->setProductIds($this->getProductIds((int)$object->getId()));
        }
        return $this;
    }

    /**
     * @param $dealId
     * @return array
     */
    public function getStoreIds($dealId)
    {
        $select = $this->getConnection()->select()->from(
            $this->_dealStoreTable, 'store_id')
            ->where('deal_id = ?', $dealId);
        return $this->getConnection()->fetchCol($select);
    }

    /**
     * @param $dealId
     * @return array
     */
    public function getProductIds($dealId)
    {
        $select = $this->getConnection()->select()->from(
            $this->_dealProductTable, 'product_id')
            ->where('deal_id = ?', $dealId);
        return $this->getConnection()->fetchCol($select);
    }

    /**
     * @param $dealId
     * @return string
     */
    public function getDealStartTime($dealId)
    {
        $select = $this->getConnection()->select()->from(
            $this->_dealTable, 'start_time'
        )->where(
            'deal_id = ?', $dealId
        );
        return $this->getConnection()->fetchOne($select);
    }

    /**
     * @param $dealId
     * @return string
     */
    public function getDealEndTime($dealId)
    {
        $select = $this->getConnection()->select()->from(
            $this->_dealTable, 'end_time'
        )->where(
            'deal_id = ?', $dealId
        );
        return $this->getConnection()->fetchOne($select);
    }

    /**
     * @param $dealId
     * @param $productId
     * @return string
     */
    public function getOldSpecialToDate($dealId, $productId)
    {
        $select = $this->getConnection()->select()->from(
            $this->getTable('tigren_dailydeal_old_special_price'), 'special_to_date'
        )->where(
            'deal_id = ?', $dealId
        )->where(
            'product_id = ?', $productId
        );
        return $this->getConnection()->fetchOne($select);
    }

    /**
     * @param $dealId
     * @param $productId
     * @return string
     */
    public function getOldSpecialFromDate($dealId, $productId)
    {
        $select = $this->getConnection()->select()->from(
            $this->getTable('tigren_dailydeal_old_special_price'), 'special_from_date'
        )->where(
            'deal_id = ?', $dealId
        )->where(
            'product_id = ?', $productId
        );
        return $this->getConnection()->fetchOne($select);
    }

    /**
     * @param $dealId
     * @param $productId
     * @return string
     */
    public function getOldSpecialPrice($dealId, $productId)
    {
        $select = $this->getConnection()->select()->from(
            $this->getTable('tigren_dailydeal_old_special_price'), 'old_special_price'
        )->where(
            'deal_id = ?', $dealId
        )->where(
            'product_id = ?', $productId
        );
        return $this->getConnection()->fetchOne($select);
    }

    /**
     * @param $dealId
     * @param $productId
     * @return string
     */
    public function getDealProductQty($dealId, $productId)
    {
        $select = $this->getConnection()->select()->from(
            $this->getTable('tigren_dailydeal_deal_product_qty'), 'deal_product_qty'
        )->where(
            'deal_id = ?', $dealId
        )->where(
            'product_id = ?', $productId
        );
        return $this->getConnection()->fetchOne($select);
    }

    /**
     * @param $dealId
     * @param $productId
     * @param $specialToDate
     * @param $specialFromDate
     * @param $oldSpecialPrice
     */
    public function saveOldSpecialPrice($dealId, $productId, $specialToDate, $specialFromDate, $oldSpecialPrice)
    {
        $bind = [
            'deal_id' => (int)$dealId,
            'product_id' => (int)$productId,
            'special_to_date' => $specialToDate,
            'special_from_date' => $specialFromDate,
            'old_special_price' => $oldSpecialPrice
        ];
        $this->getConnection()->insert(
            $this->getTable('tigren_dailydeal_old_special_price'),
            $bind
        );
    }

    /**
     * @param $dealId
     * @param $productId
     * @param $dealProductQty
     */
    public function saveDealProductsQty($dealId, $productId, $dealProductQty)
    {
        $bind = [
            'deal_id' => (int)$dealId,
            'product_id' => (int)$productId,
            'deal_product_qty' => (int)$dealProductQty
        ];
        $this->getConnection()->insert(
            $this->getTable('tigren_dailydeal_deal_product_qty'),
            $bind
        );
    }

    /**
     * @param $dealId
     * @param $productId
     * @param $dealProductQty
     */
    public function saveDealTotalQuantity($dealId, $totalQuantity)
    {
        $data = [
            'total_quantity' => $totalQuantity
        ];
        $this->getConnection()->update(
            $this->getTable('tigren_dailydeal_deal'),
            $data,
            ['deal_id = ?' => $dealId]
        );
    }

    /**
     * @param $dealId
     * @param $productId
     * @param $dealProductQty
     */
    public function updateDealProductQty($dealId, $productId, $dealProductQty)
    {
        $data = [
            'deal_product_qty' => $dealProductQty
        ];
        $this->getConnection()->update(
            $this->getTable('tigren_dailydeal_deal_product_qty'),
            $data,
            ['deal_id = ?' => $dealId, 'product_id = ?' => $productId]
        );
    }

    /**
     * @param AbstractModel $object
     * @return \Magento\Framework\Model\ResourceModel\Db\AbstractDb
     */
    protected function _beforeSave(AbstractModel $object)
    {
        if ($object->hasData('stores') && !is_array($object->getStores())) {
            $object->setStores([$object->getStores()]);
        }
        return parent::_beforeSave($object);
    }

    /**
     * @param AbstractModel $object
     * @return $this
     * @throws \Exception
     */
    protected function _afterSave(AbstractModel $object)
    {
        $connection = $this->getConnection();
        //Add title while importing
        if (empty($object->getTitle())) {
            $title = 'Deal' . $object->getId();
            $this->_dealFactory->create()->load($object->getId())->setTitle($title)->save();
        }

        //Save Deal Stores
        $condition = ['deal_id = ?' => $object->getId()];
        $connection->delete($this->_dealStoreTable, $condition);
        $stores = $object->getStores();
        if (!empty($stores)) {
            $insertedStoreIds = [];
            $fullStoreIds = $this->getAllStoreIds();
            foreach ($stores as $storeId) {
                if (in_array($storeId, $insertedStoreIds) || !in_array((int)$storeId, $fullStoreIds)) {
                    continue;
                }
                $insertedStoreIds[] = $storeId;
                $storeInsert = ['store_id' => $storeId, 'deal_id' => $object->getId()];
                $connection->insert($this->_dealStoreTable, $storeInsert);
            }
        }

        //Save Deal Products
        $productIds = $object->getData('product_ids');
        $dealQty = $object->getData('quantity');
        if ($object->isObjectNew() && !empty($productIds)) { //When create new and product is selected
            $insertedProductIds = [];
            $productCount = 0;
            foreach ($productIds as $productId) {
                if (in_array($productId, $insertedProductIds)) {
                    continue;
                }
                $insertedProductIds[] = $productId;
                $insert = ['product_id' => $productId, 'deal_id' => $object->getId()];
                $connection->insert($this->_dealProductTable, $insert);
                //Save Qty for each Deal Products
                $this->saveDealProductsQty($object->getId(), $productId, $dealQty);
                $productCount++;
            }
            $totalQty = $object->getData('price') * $productCount;
            //Save Total Quantity for Deal
            $this->saveDealTotalQuantity($object->getId(), $totalQty);
        }

        //Save Special Price for Product
        $deal = $this->_dealFactory->create()->load($object->getId());
        if ($deal->isNotEnded()) {
            $localeDate = $this->_timezone;
            $localStartTime = $this->converToTz(
                $object->getStartTime(),
                $localeDate->getConfigTimezone()
            );
            $localEndTime = $this->converToTz(
                $object->getEndTime(),
                $localeDate->getConfigTimezone()
            );
            foreach ($productIds as $id) {
                $product = $this->_productRepository->getById($id);
                if ($product->getId()) {
                    if ($product->getTypeId() == 'configurable') {
                        $childIds = $product->getTypeInstance()->getChildrenIds($product->getId());
                        if (!empty($childIds)) {
                            foreach ($childIds[0] as $childId) {
                                $childProduct = $this->_productRepository->getById($childId);
                                $childProduct->addAttributeUpdate('special_price', $object->getPrice(), $product->getStoreId());
                                $childProduct->addAttributeUpdate('special_from_date', $localStartTime, $product->getStoreId());
                                $childProduct->addAttributeUpdate('special_to_date', $localEndTime, $product->getStoreId());
                                $childProduct->setSpecialFromDateIsFormated(true);
                                $childProduct->setSpecialToDateIsFormated(true);
                            }
                        }
                    } else {
                        $product->addAttributeUpdate('special_price', $object->getPrice(), $product->getStoreId());
                        $product->addAttributeUpdate('special_from_date', $localStartTime, $product->getStoreId());
                        $product->addAttributeUpdate('special_to_date', $localEndTime, $product->getStoreId());
                        $product->setSpecialFromDateIsFormated(true);
                        $product->setSpecialToDateIsFormated(true);
                    }
                }
            }
        } else {
            foreach ($productIds as $id) {
                $product = $this->_productRepository->getById($id);
                if ($product->getId()) {
                    if ($product->getTypeId() == 'configurable') {
                        $childIds = $product->getTypeInstance()->getChildrenIds($product->getId());
                        if (!empty($childIds)) {
                            foreach ($childIds[0] as $childId) {
                                $childProduct = $this->_productRepository->getById($childId);
                                $childProduct->addAttributeUpdate('special_price', null, $product->getStoreId());
                                $childProduct->addAttributeUpdate('special_from_date', null, $product->getStoreId());
                                $childProduct->addAttributeUpdate('special_to_date', null, $product->getStoreId());
                                $childProduct->setSpecialFromDateIsFormated(true);
                                $childProduct->setSpecialToDateIsFormated(true);
                            }
                        }
                    } else {
                        $product->addAttributeUpdate('special_price', null, $product->getStoreId());
                        $product->addAttributeUpdate('special_from_date', null, $product->getStoreId());
                        $product->addAttributeUpdate('special_to_date', null, $product->getStoreId());
                        $product->setSpecialFromDateIsFormated(true);
                        $product->setSpecialToDateIsFormated(true);
                    }
                }
            }
        }

        //Refresh cache for deals
        $this->_dailydealHelper->refreshLocalDeals();
        return $this;
    }

    /**
     * @return array
     */
    public function getAllStoreIds()
    {
        $stores = $this->_storeManager->getStores();
        $ids = array_keys($stores);
        array_unshift($ids, 0);
        return $ids;
    }

    /**
     * @param AbstractModel $object
     * @return \Magento\Framework\Model\ResourceModel\Db\AbstractDb
     * @throws \Exception
     */
    protected function _afterDelete(AbstractModel $object)
    {
        //Save Special Price for Product
        $productIds = $this->getProductIds((int)$object->getId());
        foreach ($productIds as $id) {
            $product = $this->_productFactory->create()->load($id);
            if ($product->getId()) {
                $product->addAttributeUpdate('special_price', null, $product->getStoreId());
                $product->addAttributeUpdate('special_from_date', null, $product->getStoreId());
                $product->addAttributeUpdate('special_to_date', null, $product->getStoreId());
                $product->setSpecialFromDateIsFormated(true);
                $product->setSpecialToDateIsFormated(true);
            }
        }

        //Delete product_deal association
        $condition = ['deal_id = ?' => $object->getId()];
        $connection = $this->getConnection();
        $connection->delete($this->_dealProductTable, $condition);
        $connection->delete($this->getTable('tigren_dailydeal_deal_product_qty'), $condition);

        //Refresh cache for deals
        $this->_dailydealHelper->refreshLocalDeals();
        return parent::_afterDelete($object);
    }

    /**
     * @param string $dateTime
     * @param string $toTz
     * @param string $fromTz
     * @return string
     * @throws \Exception
     */
    protected function converToTz($dateTime = '', $fromTz = '')
    {
        $dateTime = $this->_dateFilter->filter($dateTime);
        // timezone by php friendly values
        $date = new \DateTime($dateTime, new \DateTimeZone($fromTz));

        $dateTime = $date->format('Y-m-d H:i:s');

        return $dateTime;
    }

}
