<?php
/**
 * @copyright Copyright (c) 2016 www.tigren.com
 */

namespace Tigren\Dailydeal\Model;
/**
 * Class Deal
 * @package Tigren\Dailydeal\Model
 */
class Deal extends \Magento\Framework\Model\AbstractModel
{

    /**
     *
     */
    const STATUS_ENABLED = 1;
    /**
     *
     */
    const STATUS_DISABLED = 0;

    /**
     * CMS page cache tag
     */
    const CACHE_TAG = 'dailydeal_deal';

    /**
     * @var string
     */
    protected $_cacheTag = 'dailydeal_deal';

    /**
     * Prefix of model name
     *
     * @var string
     */
    protected $_dealPrefix = 'dailydeal_deal';

    /**
     * @var \Magento\Framework\App\Config\ScopeConfigInterface
     */
    protected $_scopeConfig;
    /**
     * @var \Magento\Catalog\Model\ProductFactory
     */
    protected $_productFactory;
    /**
     * @var \Magento\CatalogInventory\Api\StockStateInterface
     */
    protected $_stockItem;
    /**
     * @var \Magento\CatalogInventory\Api\StockRegistryInterface
     */
    protected $_stockItemRepository;
    /**
     * @var \Magento\Framework\Stdlib\DateTime\DateTime
     */
    protected $_date;
    /**
     * @var \Tigren\Dailydeal\Helper\Data
     */
    protected $_dailydealHelper;
    /**
     * @var \Magento\Framework\UrlInterface
     */
    protected $urlModel;
    /**
     * @var \Magento\Framework\Data\Form\FormKey
     */
    protected $_formKey;
    /**
     * @var \Magento\Sales\Model\ResourceModel\Order\Item\CollectionFactory
     */
    protected $_orderItemCollectionFactory;
    /**
     * @var \Magento\Checkout\Model\Cart
     */
    protected $cart;

    /**
     * @var
     */
    protected $_productRepository;

    /**
     * Deal constructor.
     * @param \Magento\Framework\Model\Context $context
     * @param \Magento\Framework\Registry $registry
     * @param \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig
     * @param \Magento\Catalog\Model\ProductFactory $productFactory
     * @param \Magento\CatalogInventory\Api\StockStateInterface $stockItem
     * @param \Magento\CatalogInventory\Api\StockRegistryInterface $stockItemRepository
     * @param \Magento\Framework\Stdlib\DateTime\DateTime $date
     * @param \Tigren\Dailydeal\Helper\Data $dailydealHelper
     * @param \Magento\Framework\UrlFactory $urlFactory
     * @param \Magento\Framework\Data\Form\FormKey $formKey
     * @param \Magento\Sales\Model\ResourceModel\Order\Item\CollectionFactory $orderItemCollectionFactory
     * @param \Magento\Checkout\Model\Cart $cart
     * @param \Magento\Framework\Model\ResourceModel\AbstractResource|null $resource
     * @param \Magento\Framework\Data\Collection\AbstractDb|null $resourceCollection
     * @param array $data
     */
    public function __construct(
        \Magento\Framework\Model\Context $context,
        \Magento\Framework\Registry $registry,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        \Magento\Catalog\Model\ProductFactory $productFactory,
        \Magento\CatalogInventory\Api\StockStateInterface $stockItem,
        \Magento\CatalogInventory\Api\StockRegistryInterface $stockItemRepository,
        \Magento\Framework\Stdlib\DateTime\DateTime $date,
        \Tigren\Dailydeal\Helper\Data $dailydealHelper,
        \Magento\Framework\UrlFactory $urlFactory,
        \Magento\Framework\Data\Form\FormKey $formKey,
        \Magento\Sales\Model\ResourceModel\Order\Item\CollectionFactory $orderItemCollectionFactory,
        \Magento\Checkout\Model\Cart $cart,
        \Magento\Framework\Model\ResourceModel\AbstractResource $resource = null,
        \Magento\Framework\Data\Collection\AbstractDb $resourceCollection = null,
        array $data = []
    )
    {
        $this->_scopeConfig = $scopeConfig;
        $this->_productFactory = $productFactory;
        $this->_stockItem = $stockItem;
        $this->_stockItemRepository = $stockItemRepository;
        $this->_date = $date;
        $this->_dailydealHelper = $dailydealHelper;
        $this->urlModel = $urlFactory->create();
        $this->_formKey = $formKey;
        $this->_orderItemCollectionFactory = $orderItemCollectionFactory;
        $this->cart = $cart;
        parent::__construct($context, $registry, $resource, $resourceCollection, $data);
    }

    /**
     * @return array
     */
    public function getAvailableStatuses()
    {
        return [
            self::STATUS_ENABLED => __('Enabled'),
            self::STATUS_DISABLED => __('Disabled')
        ];
    }

    /**
     * @return array
     */
    public function getAvailableProgressStatuses()
    {
        return [
            'running' => __('Running'),
            'coming' => __('Coming'),
            'ended' => __('Ended')
        ];
    }

    /**
     * @return string
     */
    public function getProductPrice()
    {
        $product = $this->_productFactory->create();
        $minProductPrice = 0;
        $productIds = $this->getProductIds();
        if ($productIds && is_array($productIds) && count($productIds) > 0) {
            $productPrices = [];
            foreach ($productIds as $productId) {
                $product->load($productId);
                $productPrices[] = $product->getPrice();
            }
            $minProductPrice = min($productPrices);
        }
        return number_format($minProductPrice, 2, '.', '');
    }

    /**
     * @return string
     */
    public function getProductQty()
    {
        $productQty = 0;
        $productIds = $this->getProductIds();
        if ($productIds && is_array($productIds) && count($productIds) > 0) {
            foreach ($productIds as $productId) {
//                $productQty += $this->stockItem->getStockQty($productId, $product->getStore()->getWebsiteId());
                $productQty += $this->_stockItemRepository->getStock($productId)->getQty();
            }
        }
        return number_format($productQty, 2, '.', '');
    }

    /**
     * @param $productId
     * @return Deal
     */
    public function loadByProductId($productId)
    {
        $dealId = $this->getResource()->getDealByProductId($productId);
        return $this->load($dealId);
    }

    /**
     * @param $path
     * @return mixed
     */
    public function getScopeConfig($path)
    {
        return $this->_scopeConfig->getValue($path, \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
    }

    /**
     * @return bool
     */
    public function isAvailable()
    {
        $nowTime = strtotime($this->_dailydealHelper->getCurrentTime());
        $startTime = strtotime($this->getDealStartTime($this->getId()));
        $endTime = strtotime($this->getDealEndTime($this->getId()));
        $remain = $this->getQuantity() - $this->getSold();

        $totalInCart = 0;
        $dealProductIds = $this->getProductIds();
        $cart = $this->cart->getQuote();
        foreach ($cart->getAllItems() as $item) {
            $productId = $item->getProductId();
            if (in_array($productId, $dealProductIds)) {
                $totalInCart += $item->getQty();
            }
        }

        if (($this->getStatus() == \Tigren\Dailydeal\Model\Deal::STATUS_ENABLED) && ($remain > 0) && ($startTime <= $nowTime) && ($nowTime <= $endTime)) {
            return true;
        }
        return false;
    }

    /**
     * @return bool
     */
    public function isNotEnded()
    {
        $nowTime = $this->_dailydealHelper->getCurrentTime();
        $startTime = strtotime($this->getDealStartTime($this->getId()));
        $endTime = strtotime($this->getDealEndTime($this->getId()));
        $remain = $this->getQuantity() - $this->getSold();
        if (($this->getStatus() == \Tigren\Dailydeal\Model\Deal::STATUS_ENABLED) && ($remain > 0) && ($nowTime <= $endTime)) {
            return true;
        }
        return false;
    }

    /**
     * @return mixed
     */
    public function getOrderItemCollection()
    {
        $productIds = $this->getProductIds();
        $startTime = $this->getStartTime();
        $endTime = $this->getEndTime();
        $collection = $this->_orderItemCollectionFactory->create()
            ->addFieldToFilter('product_id', ['in' => $productIds]);
        $collection->getSelect()
            ->where("TIMESTAMPDIFF(SECOND,'$startTime',main_table.created_at) > 0")
            ->where("TIMESTAMPDIFF(SECOND,'$endTime',main_table.created_at) < 0");
        return $collection;
    }

    /**
     * @return mixed
     */
    public function getTodayDealsEndTime()
    {
        return $this->getResource()->getTodayDealsEndTime();
    }

    /**
     * @param $dealId
     * @return mixed
     */
    public function getDealStartTime($dealId)
    {
        return $this->getResource()->getDealStartTime($dealId);
    }

    /**
     * @param $dealId
     * @return mixed
     */
    public function getDealEndTime($dealId)
    {
        return $this->getResource()->getDealEndTime($dealId);
    }

    /**
     * @param $dealId
     * @param $productId
     * @return mixed
     */
    public function getProductOldSpecialToDate($dealId, $productId)
    {
        return $this->getResource()->getOldSpecialToDate($dealId, $productId);
    }

    /**
     * @param $dealId
     * @param $productId
     * @return mixed
     */
    public function getProductOldSpecialFromDate($dealId, $productId)
    {
        return $this->getResource()->getOldSpecialFromDate($dealId, $productId);
    }

    /**
     * @param $dealId
     * @param $productId
     * @return mixed
     */
    public function getProductOldSpecialPrice($dealId, $productId)
    {
        return $this->getResource()->getOldSpecialPrice($dealId, $productId);
    }

    /**
     * @return string
     */
    public function getTitleFromProducts()
    {
        $product = $this->_productFactory->create();
        $title = '';
        $productIds = $this->getProductIds();
        foreach ($productIds as $productId) {
            $product->load($productId);
            $title .= $product->getName() . ',';
        }
        $title = rtrim($title, ',');
        return $title;
    }

    /**
     * @return mixed
     */
    public function getProductIds()
    {
        return $this->getResource()->getProductIds($this->getId());
    }

    /**
     * @param $productId
     * @return mixed
     */
    public function getDealProductQty($productId)
    {
        return $this->getResource()->getDealProductQty($this->getId(), $productId);
    }

    /**
     * @param $productId
     * @param $dealProductQty
     * @return $this
     */
    public function updateDealProductQty($productId, $dealProductQty)
    {
        $this->getResource()->updateDealProductQty($this->getId(), $productId, $dealProductQty);
        return $this;
    }

    /**
     *
     */
    protected function _construct()
    {
        $this->_init('Tigren\Dailydeal\Model\ResourceModel\Deal');
    }
}
