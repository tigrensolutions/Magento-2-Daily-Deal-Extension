<?php
/**
 * @copyright Copyright (c) 2016 www.tigren.com
 */

namespace Tigren\Dailydeal\Model\Subscriber\Source;

/**
 * Class Status
 * @package Tigren\Dailydeal\Model\Subscriber\Source
 */
class Status implements \Magento\Framework\Data\OptionSourceInterface
{

    protected $_subscriber;

    /**
     * Status constructor.
     * @param \Tigren\Dailydeal\Model\Subscriber $subscriber
     */
    public function __construct(
        \Tigren\Dailydeal\Model\Subscriber $subscriber
    ) {
        $this->_subscriber = $subscriber;
    }

    /**
     * @return array
     */
    public function toOptionArray()
    {
        $options[] = ['label' => '', 'value' => ''];
        $availableOptions = $this->_subscriber->getAvailableStatuses();
        foreach ($availableOptions as $key => $value) {
            $options[] = [
                'label' => $value,
                'value' => $key,
            ];
        }
        return $options;
    }

}
