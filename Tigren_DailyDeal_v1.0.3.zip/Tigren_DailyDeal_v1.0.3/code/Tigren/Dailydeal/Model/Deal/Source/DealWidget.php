<?php
/**
 * @copyright Copyright (c) 2016 www.tigren.com
 */

namespace Tigren\Dailydeal\Model\Deal\Source;

/**
 * Class DealWidget
 * @package Tigren\Dailydeal\Model\Deal\Source
 */
class DealWidget implements \Magento\Framework\Option\ArrayInterface
{

    private $dealFactory;

    /**
     * DealWidget constructor.
     * @param \Tigren\Dailydeal\Model\DealFactory $dealFactory
     */
    public function __construct(
        \Tigren\Dailydeal\Model\DealFactory $dealFactory
    ) {
        $this->dealFactory = $dealFactory;
    }

    /**
     * @return array
     */
    public function toOptionArray()
    {
        $deals = $this->dealFactory->create()->getCollection();
        $title = [];
        foreach ($deals as $deal) {
            $title[$deal->getDealId()] = $deal->getTitle();
        }
        return $title;
    }
}
