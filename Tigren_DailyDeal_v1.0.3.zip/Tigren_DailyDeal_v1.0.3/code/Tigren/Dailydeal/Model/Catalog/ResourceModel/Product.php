<?php
/**
 * @copyright Copyright (c) 2016 www.tigren.com
 */

namespace Tigren\Dailydeal\Model\Catalog\ResourceModel;

/**
 * Mysql resource
 */
class Product extends \Magento\Catalog\Model\ResourceModel\Product
{
    protected $_dealFactory;

    /**
     * Product constructor.
     * @param \Magento\Eav\Model\Entity\Context $context
     * @param \Magento\Store\Model\StoreManagerInterface $storeManager
     * @param \Magento\Catalog\Model\Factory $modelFactory
     * @param \Magento\Catalog\Model\ResourceModel\Category\CollectionFactory $categoryCollectionFactory
     * @param \Magento\Catalog\Model\ResourceModel\Category $catalogCategory
     * @param \Magento\Framework\Event\ManagerInterface $eventManager
     * @param \Magento\Eav\Model\Entity\Attribute\SetFactory $setFactory
     * @param \Magento\Eav\Model\Entity\TypeFactory $typeFactory
     * @param \Magento\Catalog\Model\Product\Attribute\DefaultAttributes $defaultAttributes
     * @param \Tigren\Dailydeal\Model\DealFactory $dealFactory
     * @param array $data
     */
    public function __construct(
        \Magento\Eav\Model\Entity\Context $context,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Magento\Catalog\Model\Factory $modelFactory,
        \Magento\Catalog\Model\ResourceModel\Category\CollectionFactory $categoryCollectionFactory,
        \Magento\Catalog\Model\ResourceModel\Category $catalogCategory,
        \Magento\Framework\Event\ManagerInterface $eventManager,
        \Magento\Eav\Model\Entity\Attribute\SetFactory $setFactory,
        \Magento\Eav\Model\Entity\TypeFactory $typeFactory,
        \Magento\Catalog\Model\Product\Attribute\DefaultAttributes $defaultAttributes,
        \Tigren\Dailydeal\Model\DealFactory $dealFactory,
        $data = []
    ) {
        parent::__construct($context, $storeManager, $modelFactory, $categoryCollectionFactory, $catalogCategory,
            $eventManager, $setFactory, $typeFactory, $defaultAttributes, $data);
        $this->_dealFactory = $dealFactory;
    }

    /**
     * @param \Magento\Framework\DataObject $object
     * @return \Magento\Catalog\Model\ResourceModel\Product
     * @throws \Exception
     */
    protected function _afterDelete(\Magento\Framework\DataObject $object)
    {
        $productId = $object->getId();
        $deal = $this->_dealFactory->create()->loadByProductId($productId);
        if ($deal->getId() && count($deal->getProductIds()) == 1) {
            $deal->delete();
        } else {
            $deal->getResource()->deleteAssociations($productId);
        }
        return parent::_afterDelete($object);
    }

}
