<?php

namespace Tigren\Dailydeal\Setup;

use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\SchemaSetupInterface;
use Magento\Framework\Setup\UpgradeSchemaInterface;
use Magento\Framework\DB\Ddl\Table;

/**
 * Class UpgradeSchema
 * @package Tigren\Dailydeal\Setup
 */
class UpgradeSchema implements UpgradeSchemaInterface
{
    /**
     * @param SchemaSetupInterface $setup
     * @throws \Zend_Db_Exception
     */
    public function UpgradeTo103(SchemaSetupInterface $setup)
    {
        $tableName = $setup->getTable('tigren_dailydeal_old_special_price');
        $table = $setup->getConnection()
            ->newTable($tableName)
            ->addColumn(
                'deal_id',
                Table::TYPE_INTEGER,
                null,
                ['unsigned' => true, 'nullable' => false],
                'Deal ID'
            )
            ->addColumn(
                'product_id',
                Table::TYPE_INTEGER,
                null,
                ['nullable' => false],
                'product Id'
            )
            ->addColumn(
                'special_to_date',
                Table::TYPE_DATETIME,
                null,
                ['nullable' => false],
                'Special To Date'
            )
            ->addColumn(
                'special_from_date',
                Table::TYPE_DATETIME,
                null,
                ['nullable' => false],
                'Special From Date'
            )
            ->addColumn(
                'old_special_price',
                Table::TYPE_DECIMAL,
                '10,2',
                ['nullable' => false, 'default' => '0.00'],
                'old Special Price'
            )
            ->addForeignKey(
                $setup->getFkName(
                    $setup->getTable('tigren_dailydeal_old_special_price'),
                    'deal_id',
                    $setup->getTable('tigren_dailydeal_deal'),
                    'deal_id'
                ),
                'deal_id',
                $setup->getTable('tigren_dailydeal_deal'),
                'deal_id',
                Table::ACTION_CASCADE
            );

        $setup->getConnection()->createTable($table);
    }

    /**
     * @param SchemaSetupInterface $setup
     * @throws \Zend_Db_Exception
     */
    public function UpgradeTo104(SchemaSetupInterface $setup)
    {
        $tableName = $setup->getTable('tigren_dailydeal_deal_product_qty');
        $table = $setup->getConnection()
            ->newTable($tableName)
            ->addColumn(
                'deal_id',
                Table::TYPE_INTEGER,
                null,
                ['unsigned' => true, 'nullable' => false],
                'Deal ID'
            )
            ->addColumn(
                'product_id',
                Table::TYPE_INTEGER,
                null,
                ['nullable' => false],
                'product Id'
            )
            ->addColumn(
                'deal_product_qty',
                Table::TYPE_INTEGER,
                11,
                ['nullable' => false, 'default' => '0'],
                'deal product qty'
            )
            ->addForeignKey(
                $setup->getFkName(
                    $setup->getTable('tigren_dailydeal_deal_product_qty'),
                    'deal_id',
                    $setup->getTable('tigren_dailydeal_deal'),
                    'deal_id'
                ),
                'deal_id',
                $setup->getTable('tigren_dailydeal_deal'),
                'deal_id',
                Table::ACTION_CASCADE
            );

        $setup->getConnection()->createTable($table);
    }

    /**
     * @param SchemaSetupInterface $setup
     * @throws \Zend_Db_Exception
     */
    public function UpgradeTo105(SchemaSetupInterface $setup)
    {
        $setup->getConnection()->addColumn(
            $setup->getTable('tigren_dailydeal_deal'),
            'total_quantity',
            [
                'type' => \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
                'length' => 11,
                'nullable' => false,
                'comment' => 'total quantity'
            ]
        );
    }

    /**
     * @param SchemaSetupInterface $setup
     * @param ModuleContextInterface $context
     */
    public function upgrade(SchemaSetupInterface $setup, ModuleContextInterface $context)
    {
        $setup->startSetup();

        if (version_compare($context->getVersion(), '1.0.3') < 0) {
            $this->UpgradeTo103($setup);
        }
        if (version_compare($context->getVersion(), '1.0.4') < 0) {
            $this->UpgradeTo104($setup);
        }
        if (version_compare($context->getVersion(), '1.0.5') < 0) {
            $this->UpgradeTo105($setup);
        }

        $setup->endSetup();
    }
}